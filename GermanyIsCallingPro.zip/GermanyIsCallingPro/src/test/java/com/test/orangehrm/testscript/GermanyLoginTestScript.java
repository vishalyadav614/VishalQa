package com.test.orangehrm.testscript;

import org.testng.annotations.Test;

import com.orange_hrm_loginpage.HomePage;
import com.orange_hrm_loginpage.LoginPage;
public class GermanyLoginTestScript extends BaseClassPage{
	private LoginPage LoginPageObj;



	@Test(priority = 0)
	public void verifyValidCredencialUserLogin(){
		HomePage ab=new HomePage(utilObj);
		ab.clickPopupBT();
		LoginPageObj = new LoginPage(utilObj);
		LoginPageObj.loginWithValidCredential("vishal.qa2004@gmail.com", "vishal2004");
		utilObj.verifyGetTitle("Upload your CV | Germany Is Calling");
		LoginPageObj.logOut();
		utilObj.close();

	}
	@Test(priority = 1)
	public void verifyInValidCredencialUserLogin(){
		HomePage ab2=new HomePage(utilObj);
		ab2.clickPopupBT();
		LoginPage LoginPageObj1 = new LoginPage(utilObj);
		LoginPageObj1.loginWithInValidCredential("vishal.qa2004@gmail.com", "vish6776al2004");
		utilObj.verifyGetTitle("Login | Germany Is Calling");

	}








}






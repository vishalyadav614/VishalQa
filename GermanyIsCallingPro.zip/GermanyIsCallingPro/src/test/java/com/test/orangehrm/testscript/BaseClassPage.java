package com.test.orangehrm.testscript;

import java.lang.reflect.Method;


import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;


import com.orange_hrm_loginpage.LoginPage;
import com.orange_hrm_webutil.UtilPage;

public class BaseClassPage {

	protected com.orange_hrm_webutil.UtilPage utilObj;
	

	@BeforeSuite
	public void generatReport() {
		UtilPage.genrateExtentReport();

	}
	@BeforeTest
	public void importFileFromExcel() {
		
	}

	@BeforeClass
	public void beforeClass() {
		utilObj = new UtilPage();
	}

	@BeforeMethod
	public void login( Method testName) {
		utilObj.createReport(testName.getName() );
		utilObj.launchedBrowser("chromebrowser");
		utilObj.openUrl("https://germanyiscalling.com/");
		
			}

	@AfterMethod
	public void takeScreenShot(ITestResult result, Method testName) throws InterruptedException {
		if (result.getStatus() == ITestResult.FAILURE) {
			utilObj.takeScreenShot(testName.getName());
		}
		Thread.sleep(1000);
	//	LoginPageObj.logOut();
		utilObj.flushReport();

	}

	@AfterClass
	public void logout() {
				utilObj.quite();
	}

	@AfterSuite
	public void closeBrowser() {
		utilObj.flushReport();
	}

}

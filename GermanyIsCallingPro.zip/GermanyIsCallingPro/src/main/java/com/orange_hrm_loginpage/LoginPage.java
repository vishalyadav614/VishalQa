package com.orange_hrm_loginpage;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;
import com.orange_hrm_webutil.UtilPage;

public class LoginPage {
	UtilPage wu;

	public LoginPage(UtilPage utilObj) {
		this.wu = utilObj;
		PageFactory.initElements(utilObj.getDriver(), this);
	}
	@FindBy(xpath= "//a[text()='Login / SignUp']")
	WebElement loginLink;
	@FindBy(name = "username")
	WebElement usernameField;

	@FindBy(name = "password")
	WebElement passwordField;

	@FindBy(xpath = "//button[text()='Log In']")
	WebElement loginButton;

	@FindBy(xpath = "//p[text()='Invalid credentials']")
	WebElement errorMessage;
	
	@FindBy(css = "#dropdownUser1")
	 WebElement userDropdown;
	
	@FindBy(xpath = "//span[contains(.,'Logout')]")
	 WebElement logOutBT ;

	public void loginWithValidCredential (String username,String password) {
		wu.click(loginLink);
		wu.clear(usernameField);
		
		wu.sendKeys(usernameField, username,"UserName textbox");
		wu.clear(passwordField);

		wu.sendKeys(passwordField,password,"Password textbox" );
		wu.click(loginButton); 
		wu.threadSleep(300);
	}
	public void loginWithInValidCredential (String user,String pass) {
		wu.click(loginLink);
		wu.clear(usernameField);
		
		wu.sendKeys(usernameField, user,"UserName textbox");
		wu.clear(passwordField);

		wu.sendKeys(passwordField,pass,"Password textbox" );
		wu.click(loginButton); 
		wu.threadSleep(300);
	}


	// click on logout link...
	public void logOut() {
		wu.click(userDropdown);
		wu.click(logOutBT); 

	}
	
}

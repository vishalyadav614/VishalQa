package com.orange_hrm_loginpage;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.orange_hrm_webutil.UtilPage;

public class HomePage {

	UtilPage wu;

	public HomePage(UtilPage utilObj) {
		this.wu = utilObj;
		PageFactory.initElements(utilObj.getDriver(), this);
	}

	@FindBy(xpath="//span[text()='PIM']")
	private WebElement PIMMenuItem;

	@FindBy(xpath="//span[text()='Time']")
	private WebElement TimeMenuItem;

	@FindBy(xpath="//button[text()='Accept']")
	private WebElement AcceptBT;


	public void clickPopupBT() {
		wu.click(AcceptBT);
	}

	public void goToPIMModule() {
		wu.click(PIMMenuItem);


	}

	public void goToTimeModule() {
		wu.click(TimeMenuItem);

	}


}

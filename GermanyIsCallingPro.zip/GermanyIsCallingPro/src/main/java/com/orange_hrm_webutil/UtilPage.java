package com.orange_hrm_webutil;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.InvalidArgumentException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.SessionNotCreatedException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.google.common.io.Files;

import lombok.Getter;
import lombok.Setter;
import net.bytebuddy.utility.RandomString;

@Getter
@Setter
public class UtilPage {

	private WebDriver driver;
	private static ExtentReports extentReport ;
	private  ExtentTest extentTest;
	private  UtilPage util;
	private Properties prop;

	public static void genrateExtentReport() {
		extentReport = new ExtentReports();
		File filesource = new File("Reports");
		if (!filesource.exists()) {
			filesource.mkdir();
		}
		DateFormat dfobj = new SimpleDateFormat("dd_MM_yyyy hh_mm_ss a");
		String timestamp = dfobj.format(new Date());
		ExtentSparkReporter SparkReport = new ExtentSparkReporter("Reports\\" + "GermanyIsCallingTestReport.html" + timestamp);
		SparkReport.config().setTheme(Theme.DARK);
		extentReport.setSystemInfo("Tester", "Rina");

		try {
			extentReport.attachReporter(SparkReport);

		} catch (Exception e) {
			extentReport = new ExtentReports();
		}

	}
	
	public synchronized ExtentTest createReport(String testCaseName) {
		if (extentReport == null) {
			genrateExtentReport();
		}
		extentTest = extentReport.createTest(testCaseName);
		
		return extentTest;
	}
	
	
	public synchronized void flushReport() {
		extentReport.flush();
//		extentTest.log(Status.INFO, "Test Case Flushed");
	}

	
	public void launchedBrowser(String browserName) {
		ChromeOptions co = new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		try {
			if (browserName.equalsIgnoreCase("chromebrowser")) {
				 driver = new ChromeDriver();
				 extentTest.log(Status.INFO, browserName + " opened successfully");

			} else if (browserName.equalsIgnoreCase("firefoxbrowser")) {
				 driver = new FirefoxDriver();
				 extentTest.log(Status.INFO, browserName + " opened successfully");

			} else if (browserName.equalsIgnoreCase("edgebrowser")) {
				 driver = new EdgeDriver();
				 extentTest.log(Status.INFO, browserName + " opened successfully");

			}

		} catch (Exception e) {
			e.printStackTrace();

		}
		maximize();
		implicitlyWait(500);
	}


	public void openUrl(String urlValue) {
		try {
			driver.get(urlValue);
			 extentTest.log(Status.INFO, urlValue + " opened successfully");

		} catch (InvalidArgumentException e) {
			 extentTest.log(Status.FAIL, urlValue + " does not opened");

		} catch (NoSuchWindowException e) {
			 extentTest.log(Status.FAIL, urlValue + " does not opened");

		} catch (Exception e) {
			 extentTest.log(Status.FAIL, urlValue + " does not opened");

		}
	}

	
	
	public String getTittle() {
		String titleText = null;
		try {
			titleText = driver.getTitle();
			extentTest.log(Status.INFO, titleText + " title  fetching correct");
		} catch (InvalidArgumentException e) {
			extentTest.log(Status.FAIL, titleText + " title does not fetching correct");

		} catch (NoSuchWindowException e) {
			extentTest.log(Status.FAIL, titleText + " title does not fetching correct");

		} catch (Exception e) {
			extentTest.log(Status.FAIL, titleText + " title does not fetching correct");
			extentTest.addScreenCaptureFromPath(titleText);
		}
		return titleText;
	}

	public void maximize() {
		try {
			driver.manage().window().maximize();
			// extentText.log(Status.PASS, "Maxmize browser successfully");
		} catch (Exception e) {
			// extentText.log(Status.FAIL, "Maxmize webbrowser not successfully");
			e.printStackTrace();

		}
	}

	
	
	public void close() {
		try {
			driver.close();
			extentTest.log(Status.INFO, "Close page successfully");
		} catch (Exception e) {
			extentTest.log(Status.FAIL, "Close page not successfully");
			e.printStackTrace();

		}
	}

	
	public  void quite() {
		try {
			driver.quit();
			extentTest.log(Status.INFO, "Quit page successfully");
		} catch (Exception e) {
			driver.quit();
			extentTest.log(Status.FAIL, "Quit page not successfully");
			e.printStackTrace();

		}
	}

	public String takeScreenShot(String testCaseImageName) {
		DateFormat dFormat = new SimpleDateFormat("MM-dd-yyyy hh-mm-ss a");
		String timeStamp = dFormat.format(new java.util.Date());
		TakesScreenshot tssobj = (TakesScreenshot) driver;
		File sourceFile = tssobj.getScreenshotAs(OutputType.FILE);
		File folderobj = new File("SnapshotsFolder");
		if (folderobj.exists() == false) {
			folderobj.mkdir();
		}
		File destinationFile = new File("SnapshotsFolder\\" + testCaseImageName + "" + timeStamp + ".JPG");
		try {
			Files.copy(sourceFile, destinationFile);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return destinationFile.getAbsolutePath();
	}
	
	public void verifyGetTitle(String expectedTitle) {
		String actualTitle = driver.getTitle();

		if (actualTitle.equalsIgnoreCase(expectedTitle)) {

			extentTest.log(Status.PASS, "Expected " + actualTitle + " Matched to Actual Data -" + expectedTitle);
		} else {

			extentTest.log(Status.FAIL, "Expected " + actualTitle + " Not Matched to Actual Data -" + expectedTitle);
			extentTest.addScreenCaptureFromPath(takeScreenShot(actualTitle));
		}
		Assert.assertEquals(expectedTitle, actualTitle);
	}

	
	public void verifyInnerTextMatched(WebElement weObj, String expectedInnerText, String elementName) {
		String actualInnerText = weObj.getText();

		if (actualInnerText.equalsIgnoreCase(expectedInnerText)) {

			extentTest.log(Status.PASS,
					elementName + " Expected " + expectedInnerText + " Matched to Actual Text-" + actualInnerText);
		} else {

			extentTest.log(Status.FAIL,
					elementName + " Expected " + expectedInnerText + " Not Matched to Actual Text -" + actualInnerText);
			extentTest.addScreenCaptureFromPath(takeScreenShot(actualInnerText));
		}
		Assert.assertEquals(expectedInnerText, actualInnerText);
	}

	
	public void verifyAlertText(String expectedAlertText, String elementName) {
		String actualText = pop_UpGetText();
		if (actualText.equalsIgnoreCase(expectedAlertText)) {
			extentTest.log(Status.PASS,
					elementName + "  text " + actualText + "  matched to " + expectedAlertText + " expected text");
		} else {
			extentTest.log(Status.FAIL, elementName + " text ' " + actualText + " ' not matched to ' "
					+ expectedAlertText + " ' expected text");
			extentTest.addScreenCaptureFromPath(takeScreenShot(elementName));

		}
	}

	public void sendKeys(WebElement webObj, String value, String elementName) {
		try {
			webObj.sendKeys(value);
			extentTest.log(Status.INFO, value + " Enter in " + elementName);
		} catch (ElementNotInteractableException e) {
			JavascriptExecutor js=(JavascriptExecutor)driver;
			js.executeScript("arguments[0].value='"+value+"'", webObj);
		} catch (StaleElementReferenceException e) {
			webObj.sendKeys("value");
			extentTest.log(Status.FAIL, value + "- entered in " + elementName + " after handling stale exception");
		} catch (NullPointerException e) {
			extentTest.log(Status.FAIL, elementName + "-  has Null in SendKeys");

		} catch (Exception e) {
			e.printStackTrace();
			extentTest.addScreenCaptureFromPath(elementName);
		}
	}

	
	public void click(WebElement webObj) {
		String elementName = webObj.getAccessibleName();
		try {
			webObj.click();
			extentTest.log(Status.INFO, "cliked on- " + elementName);
		} catch (StaleElementReferenceException e) {
			webObj.click();
			extentTest.log(Status.FAIL, "clicked on- " + elementName + " after handling stale exception");
		} catch (Exception e) {
			e.printStackTrace();
			extentTest.addScreenCaptureFromPath(elementName);
		}
	}

	
	public void clear(WebElement webObj) {
		String elementName = webObj.getAccessibleName();
		try {
			webObj.clear();
			extentTest.log(Status.INFO, "clear- " + elementName + " textbox successfully");
		} catch (ElementNotInteractableException e) {
			// js.sendKeysBy_javaScript();
		} catch (StaleElementReferenceException e) {
			webObj.clear();
			extentTest.log(Status.FAIL,
					"clear- " + elementName + " textbox successfully after handling stale exception");
		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	
	
	
	
	public String pop_UpGetText() {
		String popupText = driver.switchTo().alert().getText();
		extentTest.log(Status.INFO, "Pop-Up window Text messeage is- " + popupText);
		return popupText;
	}

	public void pop_UpHandleDismiss() {
		driver.switchTo().alert().dismiss();
		extentTest.log(Status.INFO, "Pop-Up window Handle Dissmiss Successfully");
	}
	
	public void implicitlyWait(long time) {
		try {
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(time));
			extentTest.log(Status.INFO, "Implicitly wait- is work successfully");

		} catch (Exception e) {
			e.printStackTrace();

		}
	}

	
	public WebDriverWait ExplicitlyWait() {
		WebDriverWait wDW = null;
		try {
			wDW = new WebDriverWait(driver, Duration.ofMillis(1000));
		} catch (Exception e) {
			e.printStackTrace();

		}
		return wDW;
	}

	
	public String getRandomName(int StringSize) {
		RandomString str = new RandomString(StringSize);
		String randomStr = str.nextString();

		return randomStr;

	}

	public void threadSleep(int time) {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}		
	}
	
	public Actions actionClick(WebElement webObj) {
		String elementName = webObj.getAccessibleName();
		Actions actObj = new Actions(getDriver());
		try {
			actObj.click(webObj).build().perform();
			extentTest.log(Status.INFO, "cliked By mouse on- " + elementName);
		} catch (ElementNotInteractableException e) {
		} catch (StaleElementReferenceException e) {
			actObj.click(webObj).build().perform();
			extentTest.log(Status.FAIL, "clicked By mouse on- " + elementName + " after handling stale exception");
		} catch (Exception e) {
			e.printStackTrace();

		}
		return actObj;
	}
	
	public Actions actionScrollByElement(WebElement webObj) {
		String elementName = webObj.getAccessibleName();
		Actions actObj = new Actions(getDriver());
		try {
			actObj.scrollToElement(webObj).build().perform();
			extentTest.log(Status.INFO, "Scroll Page By mouse on- " + elementName);
		} catch (ElementNotInteractableException e) {
		} catch (StaleElementReferenceException e) {
			actObj.scrollToElement(webObj).build().perform();
			extentTest.log(Status.FAIL, "Scroll Page By mouse on- " + elementName + " after handling stale exception");
		} catch (Exception e) {
			e.printStackTrace();

		}
		return actObj;
	}
	
	public Actions actionScrollByAmount() {
		Actions actObj = new Actions(getDriver());
		try {
			actObj.scrollByAmount(0, 300).build().perform();
			extentTest.log(Status.INFO, "Scroll Page By mouse on- ");
		} catch (ElementNotInteractableException e) {
		} catch (StaleElementReferenceException e) {
			actObj.scrollByAmount(0, 300).build().perform();
			extentTest.log(Status.FAIL, "Scroll Page By mouse on- "+ " after handling stale exception");
		} catch (Exception e) {
			e.printStackTrace();

		}
		return actObj;
	}
	
	
	public Actions actionMouseOver(WebElement webObj) {
		String elementName = webObj.getAccessibleName();
		Actions actObj = new Actions(getDriver());
		try {
			actObj.moveToElement(webObj).build().perform();
			extentTest.log(Status.INFO, "MouseOver By Mouse on- " + elementName);

		} catch (ElementNotInteractableException e) {
		} catch (StaleElementReferenceException e) {
			actObj.moveToElement(webObj).build().perform();
			extentTest.log(Status.FAIL, "MouseOver By mouse on- " + elementName + " after handling stale exception");
		} catch (Exception e) {
			e.printStackTrace();

		}
		return actObj;
	}
	
	// Read Data from properties file...
	public Properties propertiFile(String filename) {

		Properties properties = null;

		try {
			properties = new Properties();
			InputStream fIS = new FileInputStream(new File(System.getProperty("user.dir")+"\\src\\test\\resources\\config\\"+filename+".properties"));
			properties.load(fIS);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return properties;
	}

}